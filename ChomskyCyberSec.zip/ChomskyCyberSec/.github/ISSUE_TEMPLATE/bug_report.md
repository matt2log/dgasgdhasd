---
name: Bug Report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear and concise description of what the bug is.

## Steps to Reproduce
1. Go to '...'
2. Click on '....'
3. Enter '....'
4. See error

## Expected Behavior
A clear and concise description of what you expected to happen.

## Actual Behavior
What actually happened.

## Environment
- **OS**: [e.g., Ubuntu 22.04, macOS 13, Windows 11]
- **Compiler**: [e.g., g++ 11.3.0, clang++ 14.0.0]
- **C++ Standard**: [e.g., C++17]
- **Build Command**: [e.g., make, manual g++ command]

## Error Messages
```
Paste any error messages or compiler output here
```

## Code Snippet (if applicable)
```cpp
// Paste relevant code here
```

## Additional Context
Add any other context about the problem here.

## Possible Solution (optional)
If you have an idea of how to fix it, please share!
