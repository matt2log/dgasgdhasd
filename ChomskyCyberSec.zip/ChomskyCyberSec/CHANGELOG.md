# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-11-10

### Added
- Initial release of Chomsky Hierarchy Cybersecurity Simulator
- DFA (Deterministic Finite Automaton) implementation with minimization
- NFA (Nondeterministic Finite Automaton) with epsilon transitions
- PDA (Pushdown Automaton) for protocol validation
- Regex parser with Thompson's construction algorithm
- Subset construction for NFA to DFA conversion
- DFA minimization using partition refinement
- Interactive CLI with 6 demonstration modes:
  1. DFA Pattern Matching for security threats
  2. Custom Regex to DFA Converter
  3. DFA Minimization Demo
  4. PDA Protocol Validation
  5. Chomsky Hierarchy Limitations Demo
  6. Performance Comparison: DFA vs PDA
- Security pattern library:
  - SQL Injection detection
  - XSS (Cross-Site Scripting) detection
  - Command Injection detection
  - Path Traversal detection
- Protocol validators:
  - TCP 3-way handshake validator
  - Balanced parentheses checker
  - Nested HTML tag validator
- Cross-platform support (Linux, macOS, Windows)
- Comprehensive documentation
- GitHub Actions CI/CD workflows
- Example patterns and test cases
- MIT License
- Contributing guidelines

### Technical Details
- C++17 standard
- Standard library only (no external dependencies)
- Optimized O(n) pattern matching with DFAs
- Stack-based PDA recognition
- Educational demonstrations of formal language theory

## [Unreleased]

### Planned Features
- Graphviz visualization of automata
- Web-based interactive interface
- Real network traffic integration (pcap files)
- Turing Machine implementation
- Context-sensitive grammar support
- More complex protocol validators
- Performance profiling tools
- Additional security patterns
- Regex pattern library
- Save/load automata configurations
- Export automata in various formats

---

## Version History

- **v1.0.0** - Initial release with complete DFA, NFA, PDA implementations
