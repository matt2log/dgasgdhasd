# Contributing to Chomsky Hierarchy Cybersecurity Simulator

Thank you for your interest in contributing! This project is educational and welcomes contributions that enhance its teaching value.

## How to Contribute

### Reporting Bugs

If you find a bug, please open an issue with:
- Description of the bug
- Steps to reproduce
- Expected behavior
- Actual behavior
- Your environment (OS, compiler version)

### Suggesting Enhancements

We welcome suggestions for:
- New security patterns
- Additional protocol validators
- Performance improvements
- Educational features
- Documentation improvements

### Pull Requests

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the existing code style
   - Add comments for complex logic
   - Update documentation if needed

4. **Test your changes**
   ```bash
   make clean
   make
   ./cybersec_simulator
   ```

5. **Commit with clear messages**
   ```bash
   git commit -m "Add feature: your feature description"
   ```

6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Open a Pull Request**
   - Describe what you changed and why
   - Reference any related issues

## Code Style Guidelines

### C++ Style
- Use **C++17** features
- Follow **STL conventions**
- Use meaningful variable names
- Add comments for complex algorithms
- Keep functions focused and small

### File Organization
- Headers in `include/`
- Implementations in `src/`
- Examples in `examples/`
- Keep the structure clean

### Example Code Style
```cpp
// Good: Clear, documented, uses STL
void DFA::addTransition(int from, char symbol, int to) {
    transitions[{from, symbol}] = to;
    alphabet.insert(symbol);
    addState(from);
    addState(to);
}

// Bad: Unclear, no validation
void addT(int f, char s, int t) {
    tr[{f,s}]=t;
}
```

## Areas for Contribution

### Easy (Good First Issues)
- Add new security patterns to `SecurityPatterns.cpp`
- Improve documentation and examples
- Fix typos or formatting
- Add more test cases

### Medium
- Implement new protocol validators
- Add visualization features
- Improve error messages
- Optimize performance

### Advanced
- Add Turing Machine implementation
- Implement context-sensitive grammars
- Add graphical state diagram generation
- Create web-based interface

## Testing Your Contributions

Before submitting:

1. **Build successfully**
   ```bash
   make clean && make
   ```

2. **Test all features**
   - Run the simulator
   - Test each menu option
   - Verify your changes work

3. **Check for warnings**
   ```bash
   make clean
   g++ -std=c++17 -Wall -Wextra -Werror -Iinclude src/*.cpp -o test
   ```

4. **Verify cross-platform** (if possible)
   - Test on Linux/Mac/Windows
   - Or rely on GitHub Actions

## Adding New Features

### Adding a Security Pattern

Edit `src/SecurityPatterns.cpp`:

```cpp
SecurityPattern newPattern;
newPattern.name = "Pattern Name";
newPattern.description = "What it detects";
newPattern.regex = "your_regex_here";

RegexParser parser;
NFA nfa = parser.parse(newPattern.regex);
newPattern.dfa = nfa.convertToDFA();

patterns.push_back(newPattern);
```

### Adding a Protocol Validator

Create a PDA in `src/SecurityPatterns.cpp`:

```cpp
PDA createYourProtocolPDA() {
    PDA pda;
    
    // Setup
    pda.setStartState(0);
    pda.setInitialStackSymbol('Z');
    pda.addAcceptState(finalState);
    
    // Add transitions
    // pda.addTransition(from, input, stackTop, to, push)
    
    return pda;
}
```

Then add it to `getProtocolValidators()`.

## Documentation

When adding features, update:
- **README.md** - If it's a major feature
- **USAGE.md** - If users interact with it
- **PROJECT.md** - If it changes architecture
- **Code comments** - Always document your code

## Questions?

Open an issue with the "question" label. We're happy to help!

## Code of Conduct

- Be respectful and inclusive
- Focus on educational value
- Help others learn
- Give constructive feedback
- Keep discussions professional

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

Thank you for helping make this educational project better! 🎓🔒
