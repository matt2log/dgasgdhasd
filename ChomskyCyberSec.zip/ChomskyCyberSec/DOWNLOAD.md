# How to Download and Run Locally

## Option 1: Download from Replit (Quick)

1. **Download the ZIP:**
   - Click the three-dot menu (⋮) in the Files panel
   - Select "Download as ZIP"
   - Extract on your computer

2. **Files to Keep:**
   ```
   include/          ← All header files
   src/              ← All source files  
   examples/         ← Example patterns
   Makefile          ← Build system
   README.md         ← Documentation
   USAGE.md          ← Usage guide
   PROJECT.md        ← Architecture docs
   ```

3. **Files to Ignore/Delete:**
   ```
   .replit           ← Replit config (not needed)
   .config/          ← Replit settings (not needed)
   .cache/           ← Temporary cache
   .upm/             ← Package manager
   obj/              ← Compiled objects (rebuild locally)
   cybersec_simulator ← Executable (rebuild locally)
   ```

## Option 2: Copy Files Manually

Create this structure on your local machine:

```
chomsky-cybersec-simulator/
├── include/
│   ├── DFA.h
│   ├── NFA.h
│   ├── PDA.h
│   ├── RegexParser.h
│   └── SecurityPatterns.h
├── src/
│   ├── DFA.cpp
│   ├── NFA.cpp
│   ├── PDA.cpp
│   ├── RegexParser.cpp
│   ├── SecurityPatterns.cpp
│   └── main.cpp
├── examples/
│   ├── test_patterns.txt
│   └── protocol_examples.txt
├── Makefile
├── README.md
├── USAGE.md
└── PROJECT.md
```

Copy each file's content from Replit to your local files.

## Running on Your Computer

### Windows

1. **Install MinGW-w64:**
   - Download from: https://www.mingw-w64.org/
   - Or use MSYS2: https://www.msys2.org/
   - Add to PATH

2. **Build:**
   ```bash
   mingw32-make clean
   mingw32-make
   ```

3. **Run:**
   ```bash
   cybersec_simulator.exe
   ```

### macOS

1. **Install Command Line Tools:**
   ```bash
   xcode-select --install
   ```

2. **Build:**
   ```bash
   make clean
   make
   ```

3. **Run:**
   ```bash
   ./cybersec_simulator
   ```

### Linux

1. **Install Build Tools:**
   ```bash
   sudo apt-get update
   sudo apt-get install build-essential
   ```

2. **Build:**
   ```bash
   make clean
   make
   ```

3. **Run:**
   ```bash
   ./cybersec_simulator
   ```

## VSCode Setup

### Recommended Extensions
- **C/C++** by Microsoft
- **C++ Intellisense**
- **Makefile Tools**

### Build Tasks (`.vscode/tasks.json`)

Create this file for one-click building:

```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "Build Cybersec Simulator",
            "type": "shell",
            "command": "make",
            "group": {
                "kind": "build",
                "isDefault": true
            },
            "problemMatcher": ["$gcc"]
        },
        {
            "label": "Clean Build",
            "type": "shell",
            "command": "make clean && make",
            "group": "build"
        },
        {
            "label": "Run Simulator",
            "type": "shell",
            "command": "./cybersec_simulator",
            "dependsOn": ["Build Cybersec Simulator"]
        }
    ]
}
```

Press `Ctrl+Shift+B` to build!

### Launch Configuration (`.vscode/launch.json`)

For debugging:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Debug Cybersec Simulator",
            "type": "cppdbg",
            "request": "launch",
            "program": "${workspaceFolder}/cybersec_simulator",
            "args": [],
            "stopAtEntry": false,
            "cwd": "${workspaceFolder}",
            "environment": [],
            "externalConsole": false,
            "MIMode": "gdb",
            "preLaunchTask": "Build Cybersec Simulator"
        }
    ]
}
```

Press `F5` to debug!

## Verify It Works

After building, test with:

```bash
./cybersec_simulator
```

You should see:
```
╔═══════════════════════════════════════════════════════════════╗
║   Chomsky Hierarchy Cybersecurity Simulator                 ║
║   Demonstrating Formal Language Theory in Security         ║
╚═══════════════════════════════════════════════════════════════╝
```

## Completely Standalone

This project has:
- ✅ **No Replit dependencies**
- ✅ **No external libraries required**
- ✅ **Standard C++17 only**
- ✅ **Cross-platform compatible**
- ✅ **Self-contained code**

Just C++ Standard Library - runs anywhere!

## Troubleshooting

**"make: command not found"**
- Windows: Install MinGW or use manual compilation
- Mac: Run `xcode-select --install`
- Linux: Run `sudo apt-get install build-essential`

**"g++: command not found"**
- Install a C++ compiler for your platform

**Manual compilation (no Make):**
```bash
g++ -std=c++17 -Iinclude -o cybersec_simulator \
    src/*.cpp
```

That's it! 100% portable, no cloud dependencies.
