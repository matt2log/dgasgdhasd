# Project Architecture

## Overview
This C++ application demonstrates the practical application of the Chomsky hierarchy to cybersecurity problems. It implements formal language theory concepts including regular expressions, finite automata (DFA/NFA), pushdown automata (PDA), and shows how different language classes address different security challenges.

## Core Components

### 1. DFA (Deterministic Finite Automaton)
- **Location**: `include/DFA.h`, `src/DFA.cpp`
- **Features**:
  - State transition management
  - Pattern matching with O(n) complexity
  - DFA minimization algorithm (table-filling method)
  - Used for: Security pattern detection (SQL injection, XSS, path traversal)

### 2. NFA (Nondeterministic Finite Automaton)
- **Location**: `include/NFA.h`, `src/NFA.cpp`
- **Features**:
  - Epsilon transitions
  - Subset construction algorithm for NFA→DFA conversion
  - Intermediate representation for regex parsing

### 3. PDA (Pushdown Automaton)
- **Location**: `include/PDA.h`, `src/PDA.cpp`
- **Features**:
  - Stack-based computation
  - Handles nested structures
  - Used for: TCP handshake validation, balanced parentheses, nested protocol validation

### 4. RegexParser
- **Location**: `include/RegexParser.h`, `src/RegexParser.cpp`
- **Features**:
  - Thompson's construction algorithm (Regex → NFA)
  - Supports: concatenation, alternation (|), Kleene star (*), plus (+), optional (?), grouping
  - Custom parser with recursive descent

### 5. SecurityPatterns
- **Location**: `include/SecurityPatterns.h`, `src/SecurityPatterns.cpp`
- **Predefined security patterns**:
  - SQL Injection detection
  - XSS attack detection
  - Command injection detection
  - Path traversal detection
  - TCP handshake validation
  - Balanced structure validators

## Technical Details

### Algorithms Implemented
1. **Thompson's Construction**: Regex → NFA conversion
2. **Subset Construction**: NFA → DFA conversion
3. **DFA Minimization**: State reduction using partition refinement
4. **PDA Recognition**: Stack-based recursive acceptance checking

### Security Applications
- **Regular Languages (DFA)**: Fast pattern matching for signatures
- **Context-Free Languages (PDA)**: Protocol validation requiring counting/nesting
- **Trade-offs**: Demonstrates when to use each automaton type

## Build System
- **Compiler**: g++ or clang++ with C++17 support
- **Standard**: C++17
- **Build tool**: Make
- **Commands**:
  - `make` - Build the project
  - `make clean` - Remove build artifacts
  - `make run` - Build and run

## Dependencies
- C++ Standard Library (STL)
- No external dependencies required

## Code Organization

### Header Files (`include/`)
All class definitions and public interfaces.

### Implementation Files (`src/`)
All implementation logic separated from interfaces.

### Main Application (`src/main.cpp`)
Interactive CLI with 6 demonstration modes.

### Examples (`examples/`)
Sample patterns and protocol test cases.

## Design Decisions

### Why C++?
- Performance critical for automata simulation
- STL provides excellent data structures (sets, maps, stacks)
- No runtime overhead
- Direct memory management

### Why Custom Regex Parser?
- Educational value in implementing Thompson's construction
- Full control over NFA generation
- No external dependencies
- Demonstrates the theory directly

### Why Both NFA and DFA?
- NFAs are easier to construct from regex
- DFAs are faster for matching
- Shows the conversion process (educational)

## Extensibility

### Adding New Security Patterns
Edit `src/SecurityPatterns.cpp`:
```cpp
SecurityPattern custom;
custom.name = "Pattern Name";
custom.regex = "your_regex_here";
NFA nfa = parser.parse(custom.regex);
custom.dfa = nfa.convertToDFA();
```

### Adding New Protocol Validators
Implement custom PDAs in `src/SecurityPatterns.cpp`:
```cpp
PDA createCustomPDA() {
    PDA pda;
    pda.setStartState(0);
    pda.addTransition(from, input, stackTop, to, push);
    return pda;
}
```

## Testing

The implementation has been verified with:
- Basic regex patterns (concatenation, alternation, Kleene star)
- Complex security patterns (SQL injection, XSS)
- Protocol validation (TCP handshake, balanced structures)
- Performance benchmarks across different input sizes

## Future Enhancements

Potential additions:
- Graphviz visualization of automata
- Real network traffic integration
- More complex protocol validators
- Turing Machine implementation
- Web-based interactive demo
