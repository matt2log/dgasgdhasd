# ⚡ Quick Start Guide

Get up and running with the Chomsky Hierarchy Cybersecurity Simulator in 5 minutes!

## 📥 Step 1: Get the Code

### Option A: Clone from GitHub
```bash
git clone https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator.git
cd chomsky-cybersec-simulator
```

### Option B: Download ZIP
1. Click the green "Code" button on GitHub
2. Select "Download ZIP"
3. Extract and open in terminal

## 🔧 Step 2: Install Prerequisites

### Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install build-essential
```

### macOS
```bash
xcode-select --install
```

### Windows
Install [MinGW-w64](https://www.mingw-w64.org/) or [Visual Studio Build Tools](https://visualstudio.microsoft.com/downloads/)

## 🏗️ Step 3: Build

```bash
make clean
make
```

**That's it!** You should see:
```
Build complete! Run ./cybersec_simulator to start.
```

## 🚀 Step 4: Run

```bash
./cybersec_simulator
```

You'll see the main menu:
```
╔═══════════════════════════════════════════════════════════════╗
║   Chomsky Hierarchy Cybersecurity Simulator                 ║
║   Demonstrating Formal Language Theory in Security         ║
╚═══════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────┐
│ MAIN MENU                                               │
├─────────────────────────────────────────────────────────┤
│ [1] DFA Pattern Matching (Type 3: Regular Languages)   │
│ [2] Custom Regex to DFA Converter                      │
│ [3] DFA Minimization Demo                              │
│ [4] PDA Protocol Validation (Type 2: Context-Free)     │
│ [5] Chomsky Hierarchy Limitations Demo                 │
│ [6] Performance Comparison: DFA vs PDA                 │
│ [0] Exit                                                │
└─────────────────────────────────────────────────────────┘
```

## 🎯 Step 5: Try Your First Demo

**Recommended first demo: Option [5] - Chomsky Hierarchy Limitations**

This shows you the core concept: why DFAs can't handle balanced parentheses, but PDAs can!

Type `5` and press Enter.

## 📚 Next Steps

- **Read [USAGE.md](USAGE.md)** for detailed feature explanations
- **Try creating custom patterns** in option [2]
- **Explore security patterns** in option [1]
- **Check performance** in option [6]

## 🆘 Troubleshooting

### "make: command not found"
**Solution**: Install build tools (see Step 2 above)

### "g++: command not found"
**Solution**: Install a C++ compiler

### Manual Build (without Make)
```bash
g++ -std=c++17 -Iinclude -o cybersec_simulator \
    src/DFA.cpp src/NFA.cpp src/PDA.cpp \
    src/RegexParser.cpp src/SecurityPatterns.cpp src/main.cpp
```

### Still having issues?
[Open an issue on GitHub](https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator/issues)

## 💡 Pro Tips

1. **Start with Option [5]** to understand the theory
2. **Use Option [2]** to experiment with regex patterns
3. **Check out examples/** folder for sample patterns
4. **Read PROJECT.md** to understand the architecture

## ⌨️ Keyboard Shortcuts

- Just type the number and press Enter
- Type `0` at any time to exit
- Press `Ctrl+C` to force quit

---

**Ready to learn?** Type `./cybersec_simulator` and start exploring! 🚀
