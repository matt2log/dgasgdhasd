# Chomsky Hierarchy Cybersecurity Simulator

![Build Status](https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator/workflows/Build%20and%20Test/badge.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)
![C++](https://img.shields.io/badge/C++-17-blue.svg)
![Platform](https://img.shields.io/badge/platform-Linux%20%7C%20macOS%20%7C%20Windows-lightgrey.svg)

A C++ application demonstrating the practical application of formal language theory and the Chomsky hierarchy to cybersecurity problems.

<p align="center">
  <img src="https://img.shields.io/badge/Type%203-Regular%20Languages-green.svg" alt="Type 3"/>
  <img src="https://img.shields.io/badge/Type%202-Context--Free%20Languages-orange.svg" alt="Type 2"/>
</p>

## 🎯 Overview

This simulator implements:
- **Regular Expressions → NFA → DFA** conversion pipeline
- **DFA minimization** for optimal pattern matching
- **Pattern matching engine** for security threat detection
- **Pushdown Automata (PDA)** for protocol validation
- **Interactive demonstrations** of theoretical limitations

## 🔑 Key Concepts

### Type 3: Regular Languages (DFA)
- **Use Case**: Fast pattern matching for attack signatures
- **Examples**: SQL injection, XSS, command injection, path traversal
- **Performance**: O(n) time complexity, constant space
- **Limitation**: Cannot handle nested/balanced structures

### Type 2: Context-Free Languages (PDA)
- **Use Case**: Protocol validation with nested structures
- **Examples**: TCP handshake, balanced parentheses, nested HTML tags
- **Performance**: Higher overhead due to stack operations
- **Capability**: Handles unbounded counting and nesting

## 🚀 Quick Start

### Prerequisites
- C++17 compatible compiler (g++, clang++, or MSVC)
- Make (or use manual compilation)

### Build

```bash
make clean
make
```

### Run

```bash
./cybersec_simulator
```

### Manual Compilation (without Make)

**Linux/Mac:**
```bash
g++ -std=c++17 -Iinclude -o cybersec_simulator \
    src/DFA.cpp src/NFA.cpp src/PDA.cpp \
    src/RegexParser.cpp src/SecurityPatterns.cpp src/main.cpp
```

**Windows (MinGW):**
```bash
g++ -std=c++17 -Iinclude -o cybersec_simulator.exe ^
    src/DFA.cpp src/NFA.cpp src/PDA.cpp ^
    src/RegexParser.cpp src/SecurityPatterns.cpp src/main.cpp
```

## ✨ Features

### 1. 🎯 DFA Pattern Matching
Demonstrates how security patterns are compiled into DFAs for efficient threat detection:
- Pre-built patterns for common attacks
- Real-time pattern matching simulation
- Performance metrics

### 2. 🔄 Custom Regex to DFA Converter
Interactive tool showing the complete conversion pipeline:
- Regex → NFA (Thompson's construction)
- NFA → DFA (Subset construction)
- Test string validation

### 3. 🔧 DFA Minimization
Optimizes DFAs by reducing redundant states:
- Shows state reduction metrics
- Demonstrates memory savings
- Preserves language recognition

### 4. 📡 PDA Protocol Validation
Validates protocols requiring nested structure tracking:
- TCP 3-way handshake (SYN → SYN-ACK → ACK)
- Balanced parentheses
- Nested HTML tags

### 5. 📚 Chomsky Hierarchy Limitations
Educational demo showing when DFAs fail and PDAs are necessary:
- Balanced parentheses problem
- Theoretical boundaries explained
- Practical security implications

### 6. ⚡ Performance Comparison
Benchmarks DFA vs PDA execution:
- Time complexity comparison
- Trade-offs analysis
- Security application guidance

## 📁 Project Structure

```
.
├── include/              # Header files
│   ├── DFA.h            # Deterministic Finite Automaton
│   ├── NFA.h            # Nondeterministic Finite Automaton
│   ├── PDA.h            # Pushdown Automaton
│   ├── RegexParser.h    # Regex to NFA converter
│   └── SecurityPatterns.h # Security pattern definitions
├── src/                 # Implementation files
│   ├── DFA.cpp
│   ├── NFA.cpp
│   ├── PDA.cpp
│   ├── RegexParser.cpp
│   ├── SecurityPatterns.cpp
│   └── main.cpp         # Interactive CLI
├── examples/            # Example patterns and protocols
├── .github/             # GitHub Actions workflows
├── Makefile            # Build system
├── LICENSE             # MIT License
├── README.md           # This file
├── USAGE.md            # Detailed usage guide
├── PROJECT.md          # Architecture documentation
├── CONTRIBUTING.md     # Contribution guidelines
└── DOWNLOAD.md         # Local setup instructions
```

## 🔬 Technical Implementation

### Algorithms
- **Thompson's Construction**: Converts regex to NFA with epsilon transitions
- **Subset Construction**: Converts NFA to DFA using powerset construction
- **DFA Minimization**: Partition refinement algorithm (table-filling method)
- **PDA Recognition**: Recursive acceptance checking with stack operations

### Security Patterns
- **SQL Injection**: `.*UNION.*SELECT.*`
- **XSS**: `.*<script>.*`
- **Command Injection**: `.*;.*`
- **Path Traversal**: `.*\.\..*`

### Protocol Validators
- **TCP Handshake**: S → A → F (SYN, SYN-ACK, ACK)
- **Balanced Parentheses**: Context-free language requiring stack
- **Nested Tags**: Validates balanced opening/closing tags

## 📊 Performance Characteristics

| Automaton | Time Complexity | Space Complexity | Use Case |
|-----------|----------------|------------------|----------|
| **DFA** | O(n) | O(1) | Pattern matching, signatures |
| **NFA** | O(n·m) | O(m) | Intermediate representation |
| **PDA** | O(n³) worst-case | O(n) | Protocol validation, nesting |

## 🎓 Educational Goals

This project demonstrates:
1. How formal language theory applies to real-world security
2. The practical differences between regular and context-free languages
3. When DFAs are sufficient vs. when PDAs are necessary
4. Trade-offs between computational efficiency and expressiveness
5. How attack signatures map to regular expressions
6. Why protocol validation requires context-free grammars

## 🤝 Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

Areas we'd love help with:
- 🎨 Visualization of automata (Graphviz integration)
- 🔒 Additional security patterns
- 📡 More protocol validators
- 🧪 Test coverage
- 📖 Documentation improvements

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📚 Documentation

- **[USAGE.md](USAGE.md)** - Detailed usage instructions and examples
- **[PROJECT.md](PROJECT.md)** - Architecture and technical details
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute
- **[DOWNLOAD.md](DOWNLOAD.md)** - Local setup instructions

## 🔗 Links

- [Report a Bug](https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator/issues/new?labels=bug)
- [Request a Feature](https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator/issues/new?labels=enhancement)
- [Discussions](https://github.com/YOUR_USERNAME/chomsky-cybersec-simulator/discussions)

## 🌟 Features Showcase

```
╔═══════════════════════════════════════════════════════════════╗
║   Chomsky Hierarchy Cybersecurity Simulator                 ║
║   Demonstrating Formal Language Theory in Security         ║
╚═══════════════════════════════════════════════════════════════╝

┌─────────────────────────────────────────────────────────┐
│ [1] DFA Pattern Matching (Type 3: Regular Languages)   │
│ [2] Custom Regex to DFA Converter                      │
│ [3] DFA Minimization Demo                              │
│ [4] PDA Protocol Validation (Type 2: Context-Free)     │
│ [5] Chomsky Hierarchy Limitations Demo                 │
│ [6] Performance Comparison: DFA vs PDA                 │
└─────────────────────────────────────────────────────────┘
```

## 🙏 Acknowledgments

Built as an educational tool to demonstrate:
- Formal language theory in practice
- Automata theory applications
- Computational complexity trade-offs
- Security pattern recognition

---

<p align="center">
  Made with ❤️ for computer science and cybersecurity education
</p>

<p align="center">
  <sub>⭐ Star this repo if you find it helpful!</sub>
</p>
