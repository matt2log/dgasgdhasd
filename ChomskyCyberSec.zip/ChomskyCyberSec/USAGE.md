# Usage Guide

## Running the Simulator

Start the interactive simulator:
```bash
./cybersec_simulator
```

## Menu Options

### [1] DFA Pattern Matching
Demonstrates security threat detection using pre-compiled DFAs:
- Choose from 4 security patterns (SQL injection, XSS, command injection, path traversal)
- See how DFAs efficiently scan network traffic in O(n) time
- View threat detection results with timing metrics

**Example Output:**
```
Input: "1' UNION SELECT password FROM users--"
Result: ⚠️ THREAT DETECTED
Time: 8 μs
```

### [2] Custom Regex to DFA Converter
Interactive tool to convert your own regular expressions:

**Supported Operators:**
- `ab` - Concatenation
- `a|b` - Alternation (OR)
- `a*` - Kleene star (zero or more)
- `a+` - Plus (one or more)
- `a?` - Optional
- `()` - Grouping
- `.` - Any character
- `\` - Escape special characters

**Example Session:**
```
Enter regex pattern: (a|b)*c
Step 1: Converting regex to NFA...
Step 2: Converting NFA to DFA...
Enter test string: aaabbbccc
Result: ✗ REJECTED
```

### [3] DFA Minimization Demo
Shows how DFAs can be optimized:
- Enter any regex pattern
- See the original DFA with all states
- View the minimized DFA with reduced states
- Compare state counts and memory savings

**Example:**
```
Pattern: a*b*
Original DFA: 3 states, 6 transitions
Minimized DFA: 3 states, 6 transitions
States reduced: 0 (0%)
```

### [4] PDA Protocol Validation
Validates protocols requiring nested structure tracking:

**TCP 3-Way Handshake:**
- S = SYN
- A = SYN-ACK
- F = ACK (Final)
- Valid sequence: "SAF"

**Balanced Parentheses:**
- Tests: "()", "(())", "((()))"
- Shows why DFAs cannot handle this

**Nested HTML Tags:**
- Simplified: "<" = open, ">" = close
- Valid: "<<>>", "<<<>>>"

### [5] Chomsky Hierarchy Limitations Demo
Educational demonstration of theoretical boundaries:
- Shows why DFAs fail for balanced parentheses
- Demonstrates PDA necessity for counting/nesting
- Explains practical security implications
- Validates test cases showing the difference

**Key Insight:**
```
DFAs (Type 3): Fast pattern matching (O(n))
                Cannot count unbounded nesting

PDAs (Type 2): Can handle nested structures
                Higher overhead (O(n³) worst-case)
```

### [6] Performance Comparison
Benchmarks DFA vs PDA execution:
- Tests various input sizes (10, 50, 100, 500, 1000 characters)
- Shows time complexity differences
- Displays performance ratio
- Guides when to use each automaton type

**Expected Results:**
```
┌──────────┬────────────────┬────────────────┬──────────┐
│   Size   │   DFA (μs)     │   PDA (μs)     │  Ratio   │
├──────────┼────────────────┼────────────────┼──────────┤
│       10 │              2 │              15 │      7.5 │
│      100 │             12 │             180 │     15.0 │
│     1000 │            120 │            2100 │     17.5 │
└──────────┴────────────────┴────────────────┴──────────┘
```

## Educational Use Cases

### For Students
1. Start with **[5] Chomsky Hierarchy Limitations** to understand theory
2. Try **[2] Custom Regex to DFA** to see conversion process
3. Explore **[4] PDA Protocol Validation** for context-free languages
4. Compare with **[6] Performance Comparison** for practical trade-offs

### For Security Practitioners
1. Use **[1] DFA Pattern Matching** to understand signature-based detection
2. See **[4] PDA Protocol Validation** for protocol analysis
3. Learn when to use DFAs vs PDAs for different security tasks

### For Researchers
1. Examine DFA minimization in **[3]**
2. Study implementation in source code
3. Modify security patterns in `src/SecurityPatterns.cpp`
4. Extend with new automaton types

## Advanced Usage

### Creating Custom Security Patterns

Edit `src/SecurityPatterns.cpp` to add new patterns:

```cpp
SecurityPattern customPattern;
customPattern.name = "My Pattern";
customPattern.description = "Custom security pattern";
customPattern.regex = ".*YOUR_PATTERN.*";
NFA nfa = parser.parse(customPattern.regex);
customPattern.dfa = nfa.convertToDFA();
```

### Adding New Protocol Validators

Implement custom PDAs in `src/SecurityPatterns.cpp`:

```cpp
PDA createCustomPDA() {
    PDA pda;
    pda.setStartState(0);
    pda.setInitialStackSymbol('Z');
    pda.addAcceptState(1);
    
    // Define transitions
    pda.addTransition(from, input, stackTop, to, push);
    
    return pda;
}
```

## Tips

1. **Regex Patterns**: Start simple (e.g., "ab") then add complexity
2. **Escaping**: Use backslash to escape special chars: `\\.` matches literal dot
3. **Testing**: Test edge cases like empty strings and long inputs
4. **Performance**: DFAs are always faster for pattern matching
5. **Nesting**: Use PDAs only when you need to count or match nested structures

## Common Patterns

### Security
- SQL Injection: `.*UNION.*SELECT.*`
- XSS: `.*<script>.*`
- Path Traversal: `.*\\.\\..*`
- Email: `.*@.*\\..*`

### Protocols
- TCP Handshake: S-A-F sequence
- Balanced Brackets: `(ⁿ)ⁿ` structure
- XML Tags: Nested opening/closing

## Troubleshooting

**Pattern not matching?**
- Check escape sequences
- Verify operator precedence
- Test simpler patterns first

**PDA not accepting?**
- Ensure balanced structure
- Check stack symbol configuration
- Verify transition definitions

**Performance issues?**
- Large DFAs from complex regex may be slow to minimize
- PDA backtracking depth limited to 1000 for performance
- Consider simplifying patterns

## Building from Source

```bash
make clean
make
./cybersec_simulator
```

## Exit

Press `0` at any menu to exit gracefully.
