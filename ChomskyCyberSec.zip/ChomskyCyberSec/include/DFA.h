#ifndef DFA_H
#define DFA_H

#include <string>
#include <set>
#include <map>
#include <vector>
#include <iostream>

class DFA {
private:
    std::set<int> states;
    std::set<char> alphabet;
    std::map<std::pair<int, char>, int> transitions;
    int startState;
    std::set<int> acceptStates;
    int stateCounter;

public:
    DFA();
    DFA(const std::set<int>& states, const std::set<char>& alphabet,
        const std::map<std::pair<int, char>, int>& transitions,
        int startState, const std::set<int>& acceptStates);
    
    void addState(int state);
    void addTransition(int from, char symbol, int to);
    void setStartState(int state);
    void addAcceptState(int state);
    void setAlphabet(const std::set<char>& alpha);
    
    bool accepts(const std::string& input) const;
    
    int getStateCount() const { return states.size(); }
    int getTransitionCount() const { return transitions.size(); }
    
    void display() const;
    
    DFA minimize() const;
    
    const std::set<int>& getStates() const { return states; }
    const std::set<int>& getAcceptStates() const { return acceptStates; }
    const std::map<std::pair<int, char>, int>& getTransitions() const { return transitions; }
    int getStartState() const { return startState; }
    const std::set<char>& getAlphabet() const { return alphabet; }
};

#endif
