#ifndef NFA_H
#define NFA_H

#include <string>
#include <set>
#include <map>
#include <vector>
#include "DFA.h"

class NFA {
private:
    std::set<int> states;
    std::set<char> alphabet;
    std::map<std::pair<int, char>, std::set<int>> transitions;
    std::map<int, std::set<int>> epsilonTransitions;
    int startState;
    std::set<int> acceptStates;

    std::set<int> epsilonClosure(int state) const;
    std::set<int> epsilonClosure(const std::set<int>& stateSet) const;
    std::set<int> move(const std::set<int>& stateSet, char symbol) const;

public:
    NFA();
    NFA(const std::set<int>& states, const std::set<char>& alphabet,
        const std::map<std::pair<int, char>, std::set<int>>& transitions,
        const std::map<int, std::set<int>>& epsilonTransitions,
        int startState, const std::set<int>& acceptStates);
    
    void addState(int state);
    void addTransition(int from, char symbol, int to);
    void addEpsilonTransition(int from, int to);
    void setStartState(int state);
    void addAcceptState(int state);
    void setAlphabet(const std::set<char>& alpha);
    
    bool accepts(const std::string& input) const;
    DFA convertToDFA() const;
    
    void display() const;
    
    const std::set<int>& getStates() const { return states; }
    const std::set<int>& getAcceptStates() const { return acceptStates; }
    int getStartState() const { return startState; }
    const std::map<std::pair<int, char>, std::set<int>>& getTransitions() const { return transitions; }
    const std::map<int, std::set<int>>& getEpsilonTransitions() const { return epsilonTransitions; }
    const std::set<char>& getAlphabet() const { return alphabet; }
};

#endif
