#ifndef PDA_H
#define PDA_H

#include <string>
#include <set>
#include <map>
#include <vector>
#include <stack>
#include <iostream>

struct PDATransition {
    int toState;
    std::string pushSymbols;
};

class PDA {
private:
    std::set<int> states;
    std::set<char> inputAlphabet;
    std::set<char> stackAlphabet;
    std::map<std::tuple<int, char, char>, std::vector<PDATransition>> transitions;
    int startState;
    char initialStackSymbol;
    std::set<int> acceptStates;
    
    struct Configuration {
        int state;
        std::string remainingInput;
        std::stack<char> stack;
    };
    
    bool acceptsRecursive(Configuration config, int depth, int maxDepth) const;

public:
    PDA();
    
    void addState(int state);
    void addTransition(int from, char inputSym, char stackTop, int to, const std::string& push);
    void setStartState(int state);
    void setInitialStackSymbol(char symbol);
    void addAcceptState(int state);
    void setInputAlphabet(const std::set<char>& alpha);
    void setStackAlphabet(const std::set<char>& alpha);
    
    bool accepts(const std::string& input) const;
    
    void display() const;
    
    int getStateCount() const { return states.size(); }
};

#endif
