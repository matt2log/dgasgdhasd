#ifndef REGEX_PARSER_H
#define REGEX_PARSER_H

#include <string>
#include "NFA.h"

class RegexParser {
private:
    int stateCounter;
    std::string regex;
    size_t pos;
    
    NFA parseExpression();
    NFA parseTerm();
    NFA parseFactor();
    NFA parseAtom();
    
    char peek() const;
    char consume();
    bool isAtEnd() const;
    
    NFA createBasicNFA(char symbol);
    NFA concatenate(const NFA& nfa1, const NFA& nfa2);
    NFA alternate(const NFA& nfa1, const NFA& nfa2);
    NFA kleeneStar(const NFA& nfa);

public:
    RegexParser();
    NFA parse(const std::string& regexPattern);
};

#endif
