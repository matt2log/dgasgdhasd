#ifndef SECURITY_PATTERNS_H
#define SECURITY_PATTERNS_H

#include <string>
#include <vector>
#include <map>
#include "DFA.h"
#include "PDA.h"

struct SecurityPattern {
    std::string name;
    std::string description;
    std::string regex;
    DFA dfa;
};

struct ProtocolValidator {
    std::string name;
    std::string description;
    PDA pda;
};

class SecurityPatterns {
public:
    static std::vector<SecurityPattern> getPatterns();
    static std::vector<ProtocolValidator> getProtocolValidators();
    
    static PDA createTCPHandshakePDA();
    static PDA createBalancedParenthesesPDA();
    static PDA createNestedHTMLPDA();
};

#endif
