# Overview

The Chomsky Hierarchy Cybersecurity Simulator is an educational C++ application that demonstrates how formal language theory (specifically the Chomsky hierarchy) applies to cybersecurity problems. The project implements complete pipelines for regular expressions (Type 3 languages) and context-free languages (Type 2 languages) to detect security threats and validate network protocols.

The application provides an interactive CLI with six demonstration modes that showcase:
- DFA-based pattern matching for security threat detection (SQL injection, XSS, command injection, path traversal)
- Custom regex to DFA conversion with Thompson's construction
- DFA minimization algorithms
- PDA-based protocol validation (TCP handshakes, balanced structures)
- Performance comparisons between DFA and PDA approaches
- Educational demonstrations of theoretical limitations

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Language Recognition Components

### DFA (Deterministic Finite Automaton)
**Purpose**: Efficient O(n) pattern matching for security threat detection

**Implementation approach**: 
- State-based transition tables for deterministic execution
- Table-filling method for DFA minimization
- Direct string matching without backtracking

**Use cases**: Detecting attack signatures (SQL injection, XSS, command injection, path traversal) where patterns are regular and don't require counting or nesting

**Trade-offs**: Fast and memory-efficient but cannot handle nested structures or unbounded counting

### NFA (Nondeterministic Finite Automaton)
**Purpose**: Intermediate representation for regex parsing

**Implementation approach**:
- Supports epsilon (empty) transitions for flexible state traversal
- Subset construction algorithm for NFA→DFA conversion
- Used as output of Thompson's construction algorithm

**Rationale**: NFAs are easier to construct from regex patterns but less efficient for matching, hence conversion to DFA for actual pattern matching

### PDA (Pushdown Automaton)
**Purpose**: Handle context-free languages requiring stack-based computation

**Implementation approach**:
- Stack-based state management for tracking nested structures
- Validates protocols with balanced/nested components

**Use cases**: TCP 3-way handshake validation, balanced parentheses, nested HTML tags

**Trade-offs**: Higher computational overhead than DFA but can handle structures that DFAs cannot (unbounded nesting/counting)

### RegexParser
**Purpose**: Convert regular expressions into executable automata

**Implementation approach**:
- Thompson's construction algorithm (Regex → NFA)
- Recursive descent parser
- Supports standard regex operators: concatenation, alternation (|), Kleene star (*), plus (+), optional (?), grouping ()

**Design decision**: Custom parser implementation rather than external regex library to maintain educational transparency and zero external dependencies

## Build System

**Technology**: Makefile-based build system

**Rationale**: Cross-platform compatibility (Linux, macOS, Windows with MinGW), simple dependency management, standard C++17 compilation

**Approach**: Separate compilation of components into object files with final linking step

## Application Architecture

**Pattern**: Interactive CLI menu system with modular demonstration modes

**Design principles**:
- Single executable with no runtime dependencies
- Educational focus with step-by-step demonstrations
- Performance timing metrics for algorithm comparison
- Predefined security pattern library for immediate experimentation

**Code organization**:
- Header files in `include/` directory for clear API separation
- Implementation in `src/` directory
- Example patterns in `examples/` for user reference

# External Dependencies

## Build Dependencies
- **C++17 compatible compiler** (g++, clang++, or MSVC)
- **Make** (optional, manual compilation supported)

## Runtime Dependencies
None - the application uses only C++ standard library with no external dependencies.

## Development Tools
- **GitHub Actions** for CI/CD workflows (automated building and testing)
- Standard build toolchains for cross-platform support

## Notable Design Decision
**Zero external dependencies**: All algorithms (Thompson's construction, subset construction, DFA minimization, PDA validation) are implemented from scratch using only C++ standard library. This decision was made to maximize educational value, portability, and ease of setup while demonstrating complete algorithm implementations.