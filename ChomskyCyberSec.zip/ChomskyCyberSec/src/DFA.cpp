#include "../include/DFA.h"
#include <algorithm>
#include <queue>
#include <iomanip>

DFA::DFA() : startState(-1), stateCounter(0) {}

DFA::DFA(const std::set<int>& states, const std::set<char>& alphabet,
         const std::map<std::pair<int, char>, int>& transitions,
         int startState, const std::set<int>& acceptStates)
    : states(states), alphabet(alphabet), transitions(transitions),
      startState(startState), acceptStates(acceptStates), stateCounter(states.size()) {}

void DFA::addState(int state) {
    states.insert(state);
}

void DFA::addTransition(int from, char symbol, int to) {
    transitions[{from, symbol}] = to;
    alphabet.insert(symbol);
    addState(from);
    addState(to);
}

void DFA::setStartState(int state) {
    startState = state;
    addState(state);
}

void DFA::addAcceptState(int state) {
    acceptStates.insert(state);
    addState(state);
}

void DFA::setAlphabet(const std::set<char>& alpha) {
    alphabet = alpha;
}

bool DFA::accepts(const std::string& input) const {
    int currentState = startState;
    
    for (char c : input) {
        auto it = transitions.find({currentState, c});
        if (it == transitions.end()) {
            return false;
        }
        currentState = it->second;
    }
    
    return acceptStates.find(currentState) != acceptStates.end();
}

void DFA::display() const {
    std::cout << "\n=== DFA Configuration ===" << std::endl;
    std::cout << "States: " << states.size() << std::endl;
    std::cout << "Start State: " << startState << std::endl;
    std::cout << "Accept States: ";
    for (int s : acceptStates) {
        std::cout << s << " ";
    }
    std::cout << "\n\nTransition Table:" << std::endl;
    std::cout << std::setw(8) << "State";
    for (char c : alphabet) {
        std::cout << std::setw(8) << c;
    }
    std::cout << std::endl;
    std::cout << std::string(8 + 8 * alphabet.size(), '-') << std::endl;
    
    for (int state : states) {
        std::cout << std::setw(8) << state;
        for (char c : alphabet) {
            auto it = transitions.find({state, c});
            if (it != transitions.end()) {
                std::cout << std::setw(8) << it->second;
            } else {
                std::cout << std::setw(8) << "-";
            }
        }
        if (acceptStates.find(state) != acceptStates.end()) {
            std::cout << "  [ACCEPT]";
        }
        std::cout << std::endl;
    }
    std::cout << "========================\n" << std::endl;
}

DFA DFA::minimize() const {
    std::set<int> nonAcceptStates;
    for (int s : states) {
        if (acceptStates.find(s) == acceptStates.end()) {
            nonAcceptStates.insert(s);
        }
    }
    
    std::vector<std::set<int>> partitions;
    if (!nonAcceptStates.empty()) {
        partitions.push_back(nonAcceptStates);
    }
    if (!acceptStates.empty()) {
        partitions.push_back(acceptStates);
    }
    
    bool changed = true;
    while (changed) {
        changed = false;
        std::vector<std::set<int>> newPartitions;
        
        for (const auto& partition : partitions) {
            std::map<std::vector<int>, std::set<int>> groups;
            
            for (int state : partition) {
                std::vector<int> signature;
                for (char c : alphabet) {
                    auto it = transitions.find({state, c});
                    if (it != transitions.end()) {
                        int targetState = it->second;
                        for (size_t i = 0; i < partitions.size(); i++) {
                            if (partitions[i].find(targetState) != partitions[i].end()) {
                                signature.push_back(i);
                                break;
                            }
                        }
                    } else {
                        signature.push_back(-1);
                    }
                }
                groups[signature].insert(state);
            }
            
            for (const auto& group : groups) {
                newPartitions.push_back(group.second);
            }
            
            if (groups.size() > 1) {
                changed = true;
            }
        }
        
        partitions = newPartitions;
    }
    
    std::map<int, int> stateMapping;
    int newStateId = 0;
    for (const auto& partition : partitions) {
        for (int state : partition) {
            stateMapping[state] = newStateId;
        }
        newStateId++;
    }
    
    std::set<int> newStates;
    std::map<std::pair<int, char>, int> newTransitions;
    std::set<int> newAcceptStates;
    
    for (int i = 0; i < newStateId; i++) {
        newStates.insert(i);
    }
    
    for (const auto& trans : transitions) {
        int fromNew = stateMapping[trans.first.first];
        char symbol = trans.first.second;
        int toNew = stateMapping[trans.second];
        newTransitions[{fromNew, symbol}] = toNew;
    }
    
    for (int acceptState : acceptStates) {
        newAcceptStates.insert(stateMapping[acceptState]);
    }
    
    int newStartState = stateMapping[startState];
    
    return DFA(newStates, alphabet, newTransitions, newStartState, newAcceptStates);
}
