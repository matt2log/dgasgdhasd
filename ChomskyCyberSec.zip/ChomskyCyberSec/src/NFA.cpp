#include "../include/NFA.h"
#include <queue>
#include <algorithm>

NFA::NFA() : startState(-1) {}

NFA::NFA(const std::set<int>& states, const std::set<char>& alphabet,
         const std::map<std::pair<int, char>, std::set<int>>& transitions,
         const std::map<int, std::set<int>>& epsilonTransitions,
         int startState, const std::set<int>& acceptStates)
    : states(states), alphabet(alphabet), transitions(transitions),
      epsilonTransitions(epsilonTransitions), startState(startState),
      acceptStates(acceptStates) {}

void NFA::addState(int state) {
    states.insert(state);
}

void NFA::addTransition(int from, char symbol, int to) {
    transitions[{from, symbol}].insert(to);
    alphabet.insert(symbol);
    addState(from);
    addState(to);
}

void NFA::addEpsilonTransition(int from, int to) {
    epsilonTransitions[from].insert(to);
    addState(from);
    addState(to);
}

void NFA::setStartState(int state) {
    startState = state;
    addState(state);
}

void NFA::addAcceptState(int state) {
    acceptStates.insert(state);
    addState(state);
}

void NFA::setAlphabet(const std::set<char>& alpha) {
    alphabet = alpha;
}

std::set<int> NFA::epsilonClosure(int state) const {
    std::set<int> closure;
    std::queue<int> toProcess;
    
    closure.insert(state);
    toProcess.push(state);
    
    while (!toProcess.empty()) {
        int current = toProcess.front();
        toProcess.pop();
        
        auto it = epsilonTransitions.find(current);
        if (it != epsilonTransitions.end()) {
            for (int nextState : it->second) {
                if (closure.find(nextState) == closure.end()) {
                    closure.insert(nextState);
                    toProcess.push(nextState);
                }
            }
        }
    }
    
    return closure;
}

std::set<int> NFA::epsilonClosure(const std::set<int>& stateSet) const {
    std::set<int> closure;
    for (int state : stateSet) {
        std::set<int> stateClosure = epsilonClosure(state);
        closure.insert(stateClosure.begin(), stateClosure.end());
    }
    return closure;
}

std::set<int> NFA::move(const std::set<int>& stateSet, char symbol) const {
    std::set<int> result;
    for (int state : stateSet) {
        auto it = transitions.find({state, symbol});
        if (it != transitions.end()) {
            result.insert(it->second.begin(), it->second.end());
        }
    }
    return result;
}

bool NFA::accepts(const std::string& input) const {
    std::set<int> currentStates = epsilonClosure(startState);
    
    for (char c : input) {
        std::set<int> nextStates = move(currentStates, c);
        currentStates = epsilonClosure(nextStates);
    }
    
    for (int state : currentStates) {
        if (acceptStates.find(state) != acceptStates.end()) {
            return true;
        }
    }
    
    return false;
}

DFA NFA::convertToDFA() const {
    std::map<std::set<int>, int> dfaStateMap;
    std::queue<std::set<int>> unmarkedStates;
    int dfaStateCounter = 0;
    
    std::set<int> startClosure = epsilonClosure(startState);
    dfaStateMap[startClosure] = dfaStateCounter++;
    unmarkedStates.push(startClosure);
    
    std::set<int> dfaStates;
    std::map<std::pair<int, char>, int> dfaTransitions;
    std::set<int> dfaAcceptStates;
    
    dfaStates.insert(dfaStateMap[startClosure]);
    
    while (!unmarkedStates.empty()) {
        std::set<int> currentNFAStates = unmarkedStates.front();
        unmarkedStates.pop();
        int currentDFAState = dfaStateMap[currentNFAStates];
        
        for (int nfaState : currentNFAStates) {
            if (acceptStates.find(nfaState) != acceptStates.end()) {
                dfaAcceptStates.insert(currentDFAState);
                break;
            }
        }
        
        for (char symbol : alphabet) {
            std::set<int> nextNFAStates = epsilonClosure(move(currentNFAStates, symbol));
            
            if (!nextNFAStates.empty()) {
                if (dfaStateMap.find(nextNFAStates) == dfaStateMap.end()) {
                    dfaStateMap[nextNFAStates] = dfaStateCounter++;
                    unmarkedStates.push(nextNFAStates);
                    dfaStates.insert(dfaStateMap[nextNFAStates]);
                }
                
                dfaTransitions[{currentDFAState, symbol}] = dfaStateMap[nextNFAStates];
            }
        }
    }
    
    return DFA(dfaStates, alphabet, dfaTransitions, dfaStateMap[startClosure], dfaAcceptStates);
}

void NFA::display() const {
    std::cout << "\n=== NFA Configuration ===" << std::endl;
    std::cout << "States: " << states.size() << std::endl;
    std::cout << "Start State: " << startState << std::endl;
    std::cout << "Accept States: ";
    for (int s : acceptStates) {
        std::cout << s << " ";
    }
    std::cout << "\n\nTransitions:" << std::endl;
    for (const auto& trans : transitions) {
        std::cout << "  δ(" << trans.first.first << ", '" << trans.first.second << "') = {";
        bool first = true;
        for (int s : trans.second) {
            if (!first) std::cout << ", ";
            std::cout << s;
            first = false;
        }
        std::cout << "}" << std::endl;
    }
    
    if (!epsilonTransitions.empty()) {
        std::cout << "\nEpsilon Transitions:" << std::endl;
        for (const auto& trans : epsilonTransitions) {
            std::cout << "  δ(" << trans.first << ", ε) = {";
            bool first = true;
            for (int s : trans.second) {
                if (!first) std::cout << ", ";
                std::cout << s;
                first = false;
            }
            std::cout << "}" << std::endl;
        }
    }
    std::cout << "========================\n" << std::endl;
}
