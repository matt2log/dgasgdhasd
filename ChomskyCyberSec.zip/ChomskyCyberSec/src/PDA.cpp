#include "../include/PDA.h"
#include <tuple>

PDA::PDA() : startState(-1), initialStackSymbol('Z') {}

void PDA::addState(int state) {
    states.insert(state);
}

void PDA::addTransition(int from, char inputSym, char stackTop, int to, const std::string& push) {
    PDATransition trans;
    trans.toState = to;
    trans.pushSymbols = push;
    transitions[std::make_tuple(from, inputSym, stackTop)].push_back(trans);
    
    if (inputSym != '\0') {
        inputAlphabet.insert(inputSym);
    }
    stackAlphabet.insert(stackTop);
    for (char c : push) {
        if (c != '\0') {
            stackAlphabet.insert(c);
        }
    }
    addState(from);
    addState(to);
}

void PDA::setStartState(int state) {
    startState = state;
    addState(state);
}

void PDA::setInitialStackSymbol(char symbol) {
    initialStackSymbol = symbol;
    stackAlphabet.insert(symbol);
}

void PDA::addAcceptState(int state) {
    acceptStates.insert(state);
    addState(state);
}

void PDA::setInputAlphabet(const std::set<char>& alpha) {
    inputAlphabet = alpha;
}

void PDA::setStackAlphabet(const std::set<char>& alpha) {
    stackAlphabet = alpha;
}

bool PDA::acceptsRecursive(Configuration config, int depth, int maxDepth) const {
    if (depth > maxDepth) {
        return false;
    }
    
    if (config.remainingInput.empty()) {
        return acceptStates.find(config.state) != acceptStates.end();
    }
    
    char currentInput = config.remainingInput[0];
    char stackTop = config.stack.empty() ? '\0' : config.stack.top();
    
    auto key = std::make_tuple(config.state, currentInput, stackTop);
    auto it = transitions.find(key);
    if (it != transitions.end()) {
        for (const auto& trans : it->second) {
            Configuration newConfig;
            newConfig.state = trans.toState;
            newConfig.remainingInput = config.remainingInput.substr(1);
            newConfig.stack = config.stack;
            
            if (!newConfig.stack.empty()) {
                newConfig.stack.pop();
            }
            
            for (int i = trans.pushSymbols.length() - 1; i >= 0; i--) {
                if (trans.pushSymbols[i] != '\0') {
                    newConfig.stack.push(trans.pushSymbols[i]);
                }
            }
            
            if (acceptsRecursive(newConfig, depth + 1, maxDepth)) {
                return true;
            }
        }
    }
    
    auto epsilonKey = std::make_tuple(config.state, '\0', stackTop);
    auto epsilonIt = transitions.find(epsilonKey);
    if (epsilonIt != transitions.end()) {
        for (const auto& trans : epsilonIt->second) {
            Configuration newConfig;
            newConfig.state = trans.toState;
            newConfig.remainingInput = config.remainingInput;
            newConfig.stack = config.stack;
            
            if (!newConfig.stack.empty()) {
                newConfig.stack.pop();
            }
            
            for (int i = trans.pushSymbols.length() - 1; i >= 0; i--) {
                if (trans.pushSymbols[i] != '\0') {
                    newConfig.stack.push(trans.pushSymbols[i]);
                }
            }
            
            if (acceptsRecursive(newConfig, depth + 1, maxDepth)) {
                return true;
            }
        }
    }
    
    return false;
}

bool PDA::accepts(const std::string& input) const {
    Configuration initialConfig;
    initialConfig.state = startState;
    initialConfig.remainingInput = input;
    initialConfig.stack.push(initialStackSymbol);
    
    return acceptsRecursive(initialConfig, 0, 1000);
}

void PDA::display() const {
    std::cout << "\n=== PDA Configuration ===" << std::endl;
    std::cout << "States: " << states.size() << std::endl;
    std::cout << "Start State: " << startState << std::endl;
    std::cout << "Initial Stack Symbol: " << initialStackSymbol << std::endl;
    std::cout << "Accept States: ";
    for (int s : acceptStates) {
        std::cout << s << " ";
    }
    std::cout << "\n\nTransitions:" << std::endl;
    for (const auto& trans : transitions) {
        int from = std::get<0>(trans.first);
        char input = std::get<1>(trans.first);
        char stackTop = std::get<2>(trans.first);
        
        std::cout << "  δ(" << from << ", ";
        if (input == '\0') {
            std::cout << "ε";
        } else {
            std::cout << "'" << input << "'";
        }
        std::cout << ", " << stackTop << ") = {";
        
        bool first = true;
        for (const auto& t : trans.second) {
            if (!first) std::cout << ", ";
            std::cout << "(" << t.toState << ", ";
            if (t.pushSymbols.empty() || t.pushSymbols == "\0") {
                std::cout << "ε";
            } else {
                std::cout << t.pushSymbols;
            }
            std::cout << ")";
            first = false;
        }
        std::cout << "}" << std::endl;
    }
    std::cout << "========================\n" << std::endl;
}
