#include "../include/RegexParser.h"
#include <stdexcept>

RegexParser::RegexParser() : stateCounter(0), pos(0) {}

NFA RegexParser::parse(const std::string& regexPattern) {
    regex = regexPattern;
    pos = 0;
    stateCounter = 0;
    return parseExpression();
}

char RegexParser::peek() const {
    if (isAtEnd()) return '\0';
    return regex[pos];
}

char RegexParser::consume() {
    return regex[pos++];
}

bool RegexParser::isAtEnd() const {
    return pos >= regex.length();
}

NFA RegexParser::parseExpression() {
    NFA nfa = parseTerm();
    
    while (peek() == '|') {
        consume();
        NFA right = parseTerm();
        nfa = alternate(nfa, right);
    }
    
    return nfa;
}

NFA RegexParser::parseTerm() {
    NFA nfa = parseFactor();
    
    while (!isAtEnd() && peek() != ')' && peek() != '|') {
        NFA right = parseFactor();
        nfa = concatenate(nfa, right);
    }
    
    return nfa;
}

NFA RegexParser::parseFactor() {
    NFA nfa = parseAtom();
    
    if (peek() == '*') {
        consume();
        nfa = kleeneStar(nfa);
    } else if (peek() == '+') {
        consume();
        NFA copy = nfa;
        NFA star = kleeneStar(nfa);
        nfa = concatenate(copy, star);
    } else if (peek() == '?') {
        consume();
        NFA epsilon = createBasicNFA('\0');
        nfa = alternate(nfa, epsilon);
    }
    
    return nfa;
}

NFA RegexParser::parseAtom() {
    if (peek() == '(') {
        consume();
        NFA nfa = parseExpression();
        if (peek() != ')') {
            throw std::runtime_error("Expected closing parenthesis");
        }
        consume();
        return nfa;
    } else if (peek() == '\\') {
        consume();
        if (isAtEnd()) {
            throw std::runtime_error("Unexpected end after escape character");
        }
        char c = consume();
        return createBasicNFA(c);
    } else if (peek() == '.') {
        consume();
        NFA nfa;
        nfa.setStartState(stateCounter++);
        int acceptState = stateCounter++;
        nfa.addAcceptState(acceptState);
        
        for (char c = 32; c < 127; c++) {
            if (c != '\n' && c != '\r') {
                nfa.addTransition(nfa.getStartState(), c, acceptState);
            }
        }
        
        return nfa;
    } else if (!isAtEnd() && peek() != '*' && peek() != '+' && peek() != '?' && 
               peek() != '|' && peek() != ')') {
        char c = consume();
        return createBasicNFA(c);
    } else {
        throw std::runtime_error("Unexpected character in regex");
    }
}

NFA RegexParser::createBasicNFA(char symbol) {
    NFA nfa;
    int start = stateCounter++;
    int accept = stateCounter++;
    
    nfa.setStartState(start);
    nfa.addAcceptState(accept);
    
    if (symbol == '\0') {
        nfa.addEpsilonTransition(start, accept);
    } else {
        nfa.addTransition(start, symbol, accept);
    }
    
    return nfa;
}

NFA RegexParser::concatenate(const NFA& nfa1, const NFA& nfa2) {
    NFA result;
    
    for (int state : nfa1.getStates()) {
        result.addState(state);
    }
    for (int state : nfa2.getStates()) {
        result.addState(state);
    }
    
    for (const auto& trans : nfa1.getTransitions()) {
        for (int toState : trans.second) {
            result.addTransition(trans.first.first, trans.first.second, toState);
        }
    }
    for (const auto& trans : nfa2.getTransitions()) {
        for (int toState : trans.second) {
            result.addTransition(trans.first.first, trans.first.second, toState);
        }
    }
    
    for (const auto& epsTrans : nfa1.getEpsilonTransitions()) {
        for (int toState : epsTrans.second) {
            result.addEpsilonTransition(epsTrans.first, toState);
        }
    }
    for (const auto& epsTrans : nfa2.getEpsilonTransitions()) {
        for (int toState : epsTrans.second) {
            result.addEpsilonTransition(epsTrans.first, toState);
        }
    }
    
    result.setStartState(nfa1.getStartState());
    
    for (int acceptState : nfa1.getAcceptStates()) {
        result.addEpsilonTransition(acceptState, nfa2.getStartState());
    }
    
    for (int acceptState : nfa2.getAcceptStates()) {
        result.addAcceptState(acceptState);
    }
    
    return result;
}

NFA RegexParser::alternate(const NFA& nfa1, const NFA& nfa2) {
    NFA result;
    
    int newStart = stateCounter++;
    int newAccept = stateCounter++;
    
    result.setStartState(newStart);
    result.addAcceptState(newAccept);
    
    for (int state : nfa1.getStates()) {
        result.addState(state);
    }
    for (int state : nfa2.getStates()) {
        result.addState(state);
    }
    
    for (const auto& trans : nfa1.getTransitions()) {
        for (int toState : trans.second) {
            result.addTransition(trans.first.first, trans.first.second, toState);
        }
    }
    for (const auto& trans : nfa2.getTransitions()) {
        for (int toState : trans.second) {
            result.addTransition(trans.first.first, trans.first.second, toState);
        }
    }
    
    for (const auto& epsTrans : nfa1.getEpsilonTransitions()) {
        for (int toState : epsTrans.second) {
            result.addEpsilonTransition(epsTrans.first, toState);
        }
    }
    for (const auto& epsTrans : nfa2.getEpsilonTransitions()) {
        for (int toState : epsTrans.second) {
            result.addEpsilonTransition(epsTrans.first, toState);
        }
    }
    
    result.addEpsilonTransition(newStart, nfa1.getStartState());
    result.addEpsilonTransition(newStart, nfa2.getStartState());
    
    for (int acceptState : nfa1.getAcceptStates()) {
        result.addEpsilonTransition(acceptState, newAccept);
    }
    for (int acceptState : nfa2.getAcceptStates()) {
        result.addEpsilonTransition(acceptState, newAccept);
    }
    
    return result;
}

NFA RegexParser::kleeneStar(const NFA& nfa) {
    NFA result;
    
    int newStart = stateCounter++;
    int newAccept = stateCounter++;
    
    result.setStartState(newStart);
    result.addAcceptState(newAccept);
    
    for (int state : nfa.getStates()) {
        result.addState(state);
    }
    
    for (const auto& trans : nfa.getTransitions()) {
        for (int toState : trans.second) {
            result.addTransition(trans.first.first, trans.first.second, toState);
        }
    }
    
    for (const auto& epsTrans : nfa.getEpsilonTransitions()) {
        for (int toState : epsTrans.second) {
            result.addEpsilonTransition(epsTrans.first, toState);
        }
    }
    
    result.addEpsilonTransition(newStart, nfa.getStartState());
    result.addEpsilonTransition(newStart, newAccept);
    
    for (int acceptState : nfa.getAcceptStates()) {
        result.addEpsilonTransition(acceptState, nfa.getStartState());
        result.addEpsilonTransition(acceptState, newAccept);
    }
    
    return result;
}
