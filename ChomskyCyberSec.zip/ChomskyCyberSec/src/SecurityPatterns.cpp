#include "../include/SecurityPatterns.h"
#include "../include/RegexParser.h"

std::vector<SecurityPattern> SecurityPatterns::getPatterns() {
    std::vector<SecurityPattern> patterns;
    RegexParser parser;
    
    SecurityPattern sqlInjection;
    sqlInjection.name = "SQL Injection (UNION)";
    sqlInjection.description = "Detects SQL UNION-based injection attempts";
    sqlInjection.regex = ".*UNION.*SELECT.*";
    try {
        NFA nfa = parser.parse(sqlInjection.regex);
        sqlInjection.dfa = nfa.convertToDFA();
        patterns.push_back(sqlInjection);
    } catch (...) {}
    
    SecurityPattern xss;
    xss.name = "XSS Attack (<script> tag)";
    xss.description = "Detects basic XSS with script tags";
    xss.regex = ".*<script>.*";
    try {
        NFA nfa = parser.parse(xss.regex);
        xss.dfa = nfa.convertToDFA();
        patterns.push_back(xss);
    } catch (...) {}
    
    SecurityPattern cmdInjection;
    cmdInjection.name = "Command Injection (;)";
    cmdInjection.description = "Detects command injection with semicolons";
    cmdInjection.regex = ".*;.*";
    try {
        NFA nfa = parser.parse(cmdInjection.regex);
        cmdInjection.dfa = nfa.convertToDFA();
        patterns.push_back(cmdInjection);
    } catch (...) {}
    
    SecurityPattern pathTraversal;
    pathTraversal.name = "Path Traversal (../)";
    pathTraversal.description = "Detects directory traversal attempts";
    pathTraversal.regex = ".*\\.\\..*";
    try {
        NFA nfa = parser.parse(pathTraversal.regex);
        pathTraversal.dfa = nfa.convertToDFA();
        patterns.push_back(pathTraversal);
    } catch (...) {}
    
    return patterns;
}

PDA SecurityPatterns::createTCPHandshakePDA() {
    PDA pda;
    
    pda.setStartState(0);
    pda.setInitialStackSymbol('Z');
    pda.addAcceptState(3);
    
    pda.addTransition(0, 'S', 'Z', 1, "SZ");
    pda.addTransition(1, 'A', 'S', 2, "AZ");
    pda.addTransition(2, 'F', 'A', 3, "\0");
    
    return pda;
}

PDA SecurityPatterns::createBalancedParenthesesPDA() {
    PDA pda;
    
    pda.setStartState(0);
    pda.setInitialStackSymbol('Z');
    pda.addAcceptState(0);
    
    pda.addTransition(0, '(', 'Z', 0, "XZ");
    pda.addTransition(0, '(', 'X', 0, "XX");
    pda.addTransition(0, ')', 'X', 0, "\0");
    pda.addTransition(0, '\0', 'Z', 0, "\0");
    
    return pda;
}

PDA SecurityPatterns::createNestedHTMLPDA() {
    PDA pda;
    
    pda.setStartState(0);
    pda.setInitialStackSymbol('Z');
    pda.addAcceptState(0);
    
    pda.addTransition(0, '<', 'Z', 0, "TZ");
    pda.addTransition(0, '<', 'T', 0, "TT");
    pda.addTransition(0, '>', 'T', 0, "\0");
    pda.addTransition(0, '\0', 'Z', 0, "\0");
    
    return pda;
}

std::vector<ProtocolValidator> SecurityPatterns::getProtocolValidators() {
    std::vector<ProtocolValidator> validators;
    
    ProtocolValidator tcp;
    tcp.name = "TCP 3-Way Handshake";
    tcp.description = "Validates TCP handshake: SYN -> SYN-ACK -> ACK (represented as S-A-F)";
    tcp.pda = createTCPHandshakePDA();
    validators.push_back(tcp);
    
    ProtocolValidator parens;
    parens.name = "Balanced Parentheses";
    parens.description = "Validates balanced parentheses (nested structure)";
    parens.pda = createBalancedParenthesesPDA();
    validators.push_back(parens);
    
    ProtocolValidator html;
    html.name = "Nested HTML Tags";
    html.description = "Validates balanced HTML-like tags (< and >)";
    html.pda = createNestedHTMLPDA();
    validators.push_back(html);
    
    return validators;
}
