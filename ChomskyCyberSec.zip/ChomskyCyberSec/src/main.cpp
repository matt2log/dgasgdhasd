#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include <iomanip>
#include "../include/DFA.h"
#include "../include/NFA.h"
#include "../include/PDA.h"
#include "../include/RegexParser.h"
#include "../include/SecurityPatterns.h"

void printHeader() {
    std::cout << "\n╔═══════════════════════════════════════════════════════════════╗" << std::endl;
    std::cout << "║   Chomsky Hierarchy Cybersecurity Simulator                 ║" << std::endl;
    std::cout << "║   Demonstrating Formal Language Theory in Security         ║" << std::endl;
    std::cout << "╚═══════════════════════════════════════════════════════════════╝\n" << std::endl;
}

void printMenu() {
    std::cout << "\n┌─────────────────────────────────────────────────────────┐" << std::endl;
    std::cout << "│ MAIN MENU                                               │" << std::endl;
    std::cout << "├─────────────────────────────────────────────────────────┤" << std::endl;
    std::cout << "│ [1] DFA Pattern Matching (Type 3: Regular Languages)   │" << std::endl;
    std::cout << "│ [2] Custom Regex to DFA Converter                      │" << std::endl;
    std::cout << "│ [3] DFA Minimization Demo                              │" << std::endl;
    std::cout << "│ [4] PDA Protocol Validation (Type 2: Context-Free)     │" << std::endl;
    std::cout << "│ [5] Chomsky Hierarchy Limitations Demo                 │" << std::endl;
    std::cout << "│ [6] Performance Comparison: DFA vs PDA                 │" << std::endl;
    std::cout << "│ [0] Exit                                                │" << std::endl;
    std::cout << "└─────────────────────────────────────────────────────────┘" << std::endl;
    std::cout << "\nEnter your choice: ";
}

void dfaPatternMatching() {
    std::cout << "\n═══ DFA-Based Security Pattern Matching ═══\n" << std::endl;
    std::cout << "Regular languages (Type 3) can efficiently detect attack patterns" << std::endl;
    std::cout << "using DFAs compiled from regular expressions.\n" << std::endl;
    
    auto patterns = SecurityPatterns::getPatterns();
    
    std::cout << "Available Security Patterns:" << std::endl;
    for (size_t i = 0; i < patterns.size(); i++) {
        std::cout << "[" << (i + 1) << "] " << patterns[i].name << std::endl;
        std::cout << "    " << patterns[i].description << std::endl;
        std::cout << "    Regex: " << patterns[i].regex << std::endl;
        std::cout << "    DFA States: " << patterns[i].dfa.getStateCount() << std::endl;
    }
    
    std::cout << "\nSelect a pattern (1-" << patterns.size() << "): ";
    int choice;
    std::cin >> choice;
    std::cin.ignore();
    
    if (choice < 1 || choice > (int)patterns.size()) {
        std::cout << "Invalid choice!" << std::endl;
        return;
    }
    
    SecurityPattern& pattern = patterns[choice - 1];
    
    std::cout << "\n--- Testing Pattern: " << pattern.name << " ---" << std::endl;
    pattern.dfa.display();
    
    std::vector<std::string> testCases = {
        "normal_query",
        "SELECT * FROM users",
        "1' UNION SELECT password FROM users--",
        "<h1>Hello</h1>",
        "<script>alert('XSS')</script>",
        "ls -la; rm -rf /",
        "../../../etc/passwd",
        "safe/path/file.txt"
    };
    
    std::cout << "\nScanning simulated network traffic..." << std::endl;
    std::cout << "─────────────────────────────────────────────────────────" << std::endl;
    
    int threatsDetected = 0;
    for (const auto& testCase : testCases) {
        auto start = std::chrono::high_resolution_clock::now();
        bool matches = pattern.dfa.accepts(testCase);
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        
        std::cout << "Input: \"" << testCase << "\"" << std::endl;
        std::cout << "Result: " << (matches ? "⚠️  THREAT DETECTED" : "✓ Safe") << std::endl;
        std::cout << "Time: " << duration.count() << " μs" << std::endl;
        std::cout << std::endl;
        
        if (matches) threatsDetected++;
    }
    
    std::cout << "─────────────────────────────────────────────────────────" << std::endl;
    std::cout << "Summary: " << threatsDetected << "/" << testCases.size() 
              << " potential threats detected" << std::endl;
}

void customRegexToDFA() {
    std::cout << "\n═══ Custom Regex to DFA Converter ═══\n" << std::endl;
    std::cout << "This demonstrates Thompson's construction (Regex → NFA)" << std::endl;
    std::cout << "followed by subset construction (NFA → DFA).\n" << std::endl;
    
    std::cout << "Supported regex operators:" << std::endl;
    std::cout << "  - Concatenation: ab" << std::endl;
    std::cout << "  - Alternation: a|b" << std::endl;
    std::cout << "  - Kleene Star: a*" << std::endl;
    std::cout << "  - Plus: a+" << std::endl;
    std::cout << "  - Optional: a?" << std::endl;
    std::cout << "  - Grouping: (ab)*" << std::endl;
    std::cout << "  - Any character: ." << std::endl;
    std::cout << "  - Escape: \\. \\* \\|" << std::endl;
    
    std::cout << "\nEnter regex pattern: ";
    std::string regex;
    std::getline(std::cin, regex);
    
    try {
        RegexParser parser;
        std::cout << "\nStep 1: Converting regex to NFA..." << std::endl;
        NFA nfa = parser.parse(regex);
        nfa.display();
        
        std::cout << "Step 2: Converting NFA to DFA..." << std::endl;
        DFA dfa = nfa.convertToDFA();
        dfa.display();
        
        std::cout << "\nTest strings against this DFA" << std::endl;
        while (true) {
            std::cout << "Enter test string (or 'quit' to exit): ";
            std::string input;
            std::getline(std::cin, input);
            
            if (input == "quit") break;
            
            bool accepted = dfa.accepts(input);
            std::cout << "Result: " << (accepted ? "✓ ACCEPTED" : "✗ REJECTED") << std::endl;
        }
        
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

void dfaMinimizationDemo() {
    std::cout << "\n═══ DFA Minimization Demonstration ═══\n" << std::endl;
    std::cout << "Minimization reduces redundant states while preserving" << std::endl;
    std::cout << "the language recognized by the DFA.\n" << std::endl;
    
    std::cout << "Enter regex pattern to minimize: ";
    std::string regex;
    std::getline(std::cin, regex);
    
    try {
        RegexParser parser;
        NFA nfa = parser.parse(regex);
        DFA dfa = nfa.convertToDFA();
        
        std::cout << "\n--- Original DFA ---" << std::endl;
        std::cout << "States: " << dfa.getStateCount() << std::endl;
        std::cout << "Transitions: " << dfa.getTransitionCount() << std::endl;
        dfa.display();
        
        std::cout << "\nMinimizing DFA..." << std::endl;
        DFA minimized = dfa.minimize();
        
        std::cout << "\n--- Minimized DFA ---" << std::endl;
        std::cout << "States: " << minimized.getStateCount() << std::endl;
        std::cout << "Transitions: " << minimized.getTransitionCount() << std::endl;
        minimized.display();
        
        int stateReduction = dfa.getStateCount() - minimized.getStateCount();
        double reductionPercent = (stateReduction * 100.0) / dfa.getStateCount();
        
        std::cout << "\nOptimization Results:" << std::endl;
        std::cout << "  States reduced: " << stateReduction << " (" 
                  << reductionPercent << "%)" << std::endl;
        std::cout << "  Memory savings: ~" << (stateReduction * 8) << " bytes" << std::endl;
        
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
}

void pdaProtocolValidation() {
    std::cout << "\n═══ PDA-Based Protocol Validation ═══\n" << std::endl;
    std::cout << "Context-free languages (Type 2) require pushdown automata" << std::endl;
    std::cout << "to handle nested structures like protocol handshakes.\n" << std::endl;
    
    auto validators = SecurityPatterns::getProtocolValidators();
    
    std::cout << "Available Protocol Validators:" << std::endl;
    for (size_t i = 0; i < validators.size(); i++) {
        std::cout << "[" << (i + 1) << "] " << validators[i].name << std::endl;
        std::cout << "    " << validators[i].description << std::endl;
    }
    
    std::cout << "\nSelect a validator (1-" << validators.size() << "): ";
    int choice;
    std::cin >> choice;
    std::cin.ignore();
    
    if (choice < 1 || choice > (int)validators.size()) {
        std::cout << "Invalid choice!" << std::endl;
        return;
    }
    
    ProtocolValidator& validator = validators[choice - 1];
    
    std::cout << "\n--- Protocol Validator: " << validator.name << " ---" << std::endl;
    validator.pda.display();
    
    std::vector<std::string> testCases;
    
    if (choice == 1) {
        testCases = {"SAF", "SA", "AF", "SFA", "SSS", "AAF"};
        std::cout << "\nTest Cases (S=SYN, A=SYN-ACK, F=ACK):" << std::endl;
    } else if (choice == 2) {
        testCases = {"()", "(())", "((()))", "()()", "(()", "())", "((())"};
        std::cout << "\nTest Cases (Balanced Parentheses):" << std::endl;
    } else {
        testCases = {"<>", "<<>>", "<<<>>>", "<><>", "<<>", "<>>", "<<>>"};
        std::cout << "\nTest Cases (Balanced Tags):" << std::endl;
    }
    
    for (const auto& testCase : testCases) {
        bool valid = validator.pda.accepts(testCase);
        std::cout << "  \"" << testCase << "\" -> " 
                  << (valid ? "✓ VALID" : "✗ INVALID") << std::endl;
    }
}

void chomskyLimitationsDemo() {
    std::cout << "\n═══ Chomsky Hierarchy Limitations Demo ═══\n" << std::endl;
    std::cout << "This demonstrates the theoretical boundary between" << std::endl;
    std::cout << "regular languages (Type 3) and context-free languages (Type 2).\n" << std::endl;
    
    std::cout << "Problem: Detecting balanced parentheses" << std::endl;
    std::cout << "Language: L = {()ⁿ | n ≥ 0} = {ε, (), (()), ((())), ...}\n" << std::endl;
    
    std::cout << "--- Attempt 1: Using DFA (Regular Language) ---" << std::endl;
    std::cout << "Regular languages CANNOT count unbounded nesting." << std::endl;
    std::cout << "A DFA has finite memory (states), but balanced parentheses" << std::endl;
    std::cout << "require counting: need to remember how many '(' we've seen." << std::endl;
    std::cout << "Result: ✗ IMPOSSIBLE with DFA alone\n" << std::endl;
    
    std::cout << "--- Attempt 2: Using PDA (Context-Free Language) ---" << std::endl;
    std::cout << "PDAs have a stack, providing unbounded memory for counting." << std::endl;
    
    PDA pda = SecurityPatterns::createBalancedParenthesesPDA();
    pda.display();
    
    std::vector<std::string> testCases = {
        "",
        "()",
        "(())",
        "((()))",
        "(((())))",
        "((((())())))",
        "(()",
        "())",
        "()()(",
        ")("
    };
    
    std::cout << "\nValidating test cases:" << std::endl;
    for (const auto& test : testCases) {
        bool valid = pda.accepts(test);
        std::cout << "  \"" << test << "\" -> " 
                  << (valid ? "✓ VALID" : "✗ INVALID") << std::endl;
    }
    
    std::cout << "\nConclusion:" << std::endl;
    std::cout << "  - DFAs (Type 3): Efficient for pattern matching (O(n))" << std::endl;
    std::cout << "  - PDAs (Type 2): Required for nested structures (O(n³) worst-case)" << std::endl;
    std::cout << "  - Security implication: Choose the right automaton for the job!" << std::endl;
}

void performanceComparison() {
    std::cout << "\n═══ Performance Comparison: DFA vs PDA ═══\n" << std::endl;
    
    RegexParser parser;
    NFA nfa = parser.parse("a*b*");
    DFA dfa = nfa.convertToDFA();
    
    PDA pda = SecurityPatterns::createBalancedParenthesesPDA();
    
    std::vector<int> sizes = {10, 50, 100, 500, 1000};
    
    std::cout << "Testing string processing performance...\n" << std::endl;
    std::cout << "┌──────────┬────────────────┬────────────────┬──────────┐" << std::endl;
    std::cout << "│   Size   │   DFA (μs)     │   PDA (μs)     │  Ratio   │" << std::endl;
    std::cout << "├──────────┼────────────────┼────────────────┼──────────┤" << std::endl;
    
    for (int size : sizes) {
        std::string dfaInput(size, 'a');
        dfaInput += std::string(size, 'b');
        
        std::string pdaInput;
        for (int i = 0; i < size; i++) pdaInput += '(';
        for (int i = 0; i < size; i++) pdaInput += ')';
        
        auto dfaStart = std::chrono::high_resolution_clock::now();
        dfa.accepts(dfaInput);
        auto dfaEnd = std::chrono::high_resolution_clock::now();
        auto dfaTime = std::chrono::duration_cast<std::chrono::microseconds>(dfaEnd - dfaStart).count();
        
        auto pdaStart = std::chrono::high_resolution_clock::now();
        pda.accepts(pdaInput);
        auto pdaEnd = std::chrono::high_resolution_clock::now();
        auto pdaTime = std::chrono::duration_cast<std::chrono::microseconds>(pdaEnd - pdaStart).count();
        
        double ratio = (dfaTime > 0) ? (double)pdaTime / dfaTime : 0;
        
        std::cout << "│ " << std::setw(8) << size << " │ " 
                  << std::setw(14) << dfaTime << " │ "
                  << std::setw(14) << pdaTime << " │ "
                  << std::setw(8) << std::fixed << std::setprecision(1) << ratio << " │" << std::endl;
    }
    
    std::cout << "└──────────┴────────────────┴────────────────┴──────────┘" << std::endl;
    
    std::cout << "\nKey Observations:" << std::endl;
    std::cout << "  - DFAs: O(n) time complexity, constant space" << std::endl;
    std::cout << "  - PDAs: Higher overhead due to stack operations" << std::endl;
    std::cout << "  - Trade-off: Speed vs. Expressiveness" << std::endl;
    std::cout << "  - Security context: Use DFAs for pattern matching," << std::endl;
    std::cout << "    PDAs only when nested structures are required" << std::endl;
}

int main() {
    printHeader();
    
    while (true) {
        printMenu();
        int choice;
        std::cin >> choice;
        std::cin.ignore();
        
        switch (choice) {
            case 1:
                dfaPatternMatching();
                break;
            case 2:
                customRegexToDFA();
                break;
            case 3:
                dfaMinimizationDemo();
                break;
            case 4:
                pdaProtocolValidation();
                break;
            case 5:
                chomskyLimitationsDemo();
                break;
            case 6:
                performanceComparison();
                break;
            case 0:
                std::cout << "\nThank you for exploring the Chomsky Hierarchy!" << std::endl;
                std::cout << "Security through formal language theory. 🔒\n" << std::endl;
                return 0;
            default:
                std::cout << "\nInvalid choice. Please try again." << std::endl;
        }
        
        std::cout << "\nPress Enter to continue...";
        std::cin.get();
    }
    
    return 0;
}
